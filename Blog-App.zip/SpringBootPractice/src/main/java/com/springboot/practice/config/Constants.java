package com.springboot.practice.config;

public class Constants {
    public Constants(){

    }

    public static final String PAGE_NUMBER = "10";
    public static final String PAGE_SIZE = "10";
    public static final String SORT_BY = "postId";
    public static final String SORT_DIR = "asc";

}