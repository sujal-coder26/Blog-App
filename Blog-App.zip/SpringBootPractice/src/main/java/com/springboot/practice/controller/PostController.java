package com.springboot.practice.controller;
import com.springboot.practice.config.Constants;
import com.springboot.practice.payloads.ApiResponse;
import com.springboot.practice.payloads.PostDTO;
import com.springboot.practice.payloads.PostResponse;
import com.springboot.practice.service.PostService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/")
@RequiredArgsConstructor
public class PostController {

  private final PostService postService;

  @PostMapping("/user/{userId}/category/{categoryId}/posts")
  public ResponseEntity<PostDTO> createPost(
      @Valid @RequestBody PostDTO postDTO,
      @PathVariable Integer categoryId,
      @PathVariable Integer userId) {
    PostDTO createPost = this.postService.createPost(postDTO, categoryId, userId);
    return new ResponseEntity<>(createPost, HttpStatus.CREATED);
  }

  @PutMapping(value = "/posts/{postId}")
  public ResponseEntity<PostDTO> updatePost(
      @RequestBody PostDTO postDTO, @PathVariable Integer postId) {
    PostDTO updatedPost = this.postService.updatePost(postDTO, postId);
    return new ResponseEntity<>(updatedPost, HttpStatus.OK);
  }

  @GetMapping(value = "/category/{categoryId}/posts")
  public ResponseEntity<List<PostDTO>> listOfPostByCategory(@PathVariable Integer categoryId) {
    List<PostDTO> getAllPosts = this.postService.getPostsByCategory(categoryId);
    return new ResponseEntity<>(getAllPosts, HttpStatus.OK);
  }

  @GetMapping(value = "/user/{userId}/posts")
  public ResponseEntity<List<PostDTO>> listOfPostByUser(@PathVariable Integer userId) {
    List<PostDTO> getAllPosts = this.postService.getPostsByUser(userId);
    return new ResponseEntity<>(getAllPosts, HttpStatus.OK);
  }

  @GetMapping(value = "/posts/{postId}")
  public ResponseEntity<PostDTO> getPostWithId(
          @PathVariable Integer postId) {
    PostDTO postWithId = this.postService.getPostById(postId);
    return ResponseEntity.ok(postWithId);
  }

  @DeleteMapping(value = "/posts/{postId}")
  public ResponseEntity<ApiResponse> deletePost(@PathVariable Integer postId) {
    this.postService.delete(postId);
    return new ResponseEntity<>(new ApiResponse("Post Deleted Successfully", true), HttpStatus.OK);
  }

  @GetMapping(value = "/posts")
  public ResponseEntity<PostResponse> getAllPosts(
      @RequestParam(value = "pageNumber", defaultValue = Constants.PAGE_NUMBER, required = false) Integer pageNumber,
      @RequestParam(value = "pageSize", defaultValue = Constants.PAGE_SIZE, required = false) Integer pageSize,
      @RequestParam(value = "sortBy", defaultValue = Constants.SORT_BY, required = false) String sortBy,
    @RequestParam(value = "sortDirection", defaultValue = Constants.SORT_DIR, required = false) String sortDirection){
    PostResponse postResponse = this.postService.getAllPosts(pageNumber, pageSize, sortBy, sortDirection);
    return new ResponseEntity<>(postResponse, HttpStatus.OK);

  }

  @GetMapping(value = "/posts/search/{keyword}")
  public ResponseEntity<List<PostDTO>> getPostWithId(
          @PathVariable String keyword) {
    List<PostDTO> searchedPost = this.postService.searchPosts ( keyword );
    return new ResponseEntity<>(searchedPost, HttpStatus.OK);
  }

}
