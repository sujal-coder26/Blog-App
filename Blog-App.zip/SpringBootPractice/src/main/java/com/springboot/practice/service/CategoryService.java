package com.springboot.practice.service;

import com.springboot.practice.entities.Category;
import com.springboot.practice.payloads.CategoryDTO;

import java.util.List;

public interface CategoryService {
     CategoryDTO create(CategoryDTO categoryDTO);
     CategoryDTO update(CategoryDTO categoryDTO, Integer categoryId);
     void delete(Integer categoryId);
     CategoryDTO getCategoryById(Integer categoryId );
     List<CategoryDTO> getAllCategory();
}
