package com.springboot.practice.controller;

import com.springboot.practice.payloads.ApiResponse;
import com.springboot.practice.payloads.CategoryDTO;
import com.springboot.practice.service.CategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping(value = "/api/categories")

public class CategoryController {
    private final CategoryService categoryService;

    @PostMapping(value = "/")
    public ResponseEntity<CategoryDTO> createCategory(@Valid @RequestBody CategoryDTO categoryDTO){
        CategoryDTO createdCategory = this.categoryService.create( categoryDTO );
        return new ResponseEntity<> ( createdCategory, HttpStatus.CREATED);

    }
    @PutMapping(value = "/{categoryId}")
    public ResponseEntity<CategoryDTO> updateCategory(@Valid @RequestBody CategoryDTO categoryDTO,@PathVariable Integer categoryId){
        CategoryDTO categoryDTO1 = this.categoryService.update ( categoryDTO, categoryId );
        return new ResponseEntity<> (categoryDTO1, HttpStatus.OK);
    }

    @DeleteMapping(value = "/{categoryId}")
    public ResponseEntity<ApiResponse> deleteCategory( @PathVariable Integer categoryId){
        this.categoryService.delete (categoryId);
        return new ResponseEntity<>(new ApiResponse ("Category Deleted Successfully", true), HttpStatus.OK );
    }

    @GetMapping(value = "/{categoryId}")
    public ResponseEntity<CategoryDTO> getCategoryById(@PathVariable Integer categoryId){
        CategoryDTO categoryDTO1 = this.categoryService.getCategoryById( categoryId );
        return new ResponseEntity<> ( categoryDTO1, HttpStatus.ACCEPTED );
    }

    @GetMapping(value = "/")
    public ResponseEntity<List<CategoryDTO>> getAllUsers(){
        List<CategoryDTO> categoryDTO = this.categoryService.getAllCategory ();
        return new ResponseEntity<List<CategoryDTO>>( categoryDTO, HttpStatus.OK );
    }
}
