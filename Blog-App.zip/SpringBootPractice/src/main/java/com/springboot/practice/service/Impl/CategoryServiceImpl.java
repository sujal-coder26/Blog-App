package com.springboot.practice.service.Impl;

import com.springboot.practice.entities.Category;
import com.springboot.practice.exception.ResourceNotFoundException;
import com.springboot.practice.payloads.CategoryDTO;
import com.springboot.practice.repository.CategoryRepo;
import com.springboot.practice.service.CategoryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class CategoryServiceImpl implements CategoryService {

    private final CategoryRepo categoryRepo;
    private final ModelMapper modelMapper;

    @Override
    public CategoryDTO create ( CategoryDTO categoryDTO ) {
        Category category = this.dtoToCategory ( categoryDTO );
        Category savedCategory = this.categoryRepo.save (category);
        return this.categoryTodto( savedCategory );
    }

    @Override
    public CategoryDTO update ( CategoryDTO categoryDTO , Integer categoryId ){
        Category category = this.categoryRepo.findById ( categoryId ).orElseThrow (() -> new ResourceNotFoundException ( "Category", "categoryId", categoryId ));
        category.setCategoryId ( categoryDTO.getCategoryId () );
        category.setCategoryTitle ( categoryDTO.getCategoryTitle ());
        category.setCategoryDescription ( categoryDTO.getCategoryDescription () );

        Category updatedCategory = this.categoryRepo.save ( category );
        return this.categoryTodto ( updatedCategory );
    }

    @Override
    public void delete ( Integer categoryId ) {
        Category category = this.categoryRepo.findById ( categoryId ).orElseThrow ( () -> new ResourceNotFoundException ( "Category", "categoryId", categoryId ) );
        this.categoryRepo.delete ( category );
    }

    @Override
    public CategoryDTO getCategoryById ( Integer categoryId ) {
        Category category = this.categoryRepo.findById ( categoryId ).orElseThrow ( () -> new ResourceNotFoundException ( "Category", "categoryId", categoryId ) );
        return this.categoryTodto ( category );
    }

    @Override
    public List<CategoryDTO> getAllCategory () {
        List<Category> allCategories = this.categoryRepo.findAll();
        return allCategories.stream( ).map ( this::categoryTodto ).collect( Collectors.toList());
    }
    public CategoryDTO categoryTodto(Category category){
        return this.modelMapper.map (category, CategoryDTO.class );
    }

    public Category dtoToCategory (CategoryDTO categoryDTO){
        return this.modelMapper.map ( categoryDTO, Category.class );
    }
}
